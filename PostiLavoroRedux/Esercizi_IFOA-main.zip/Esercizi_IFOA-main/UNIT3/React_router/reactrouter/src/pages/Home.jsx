import Main from "../components/Main";
import Footer from "../components/Footer";


const Home = ({page}) => {
    return (
        <div>
            <Main page={page}/>
        </div>
    )
}


export default Home
