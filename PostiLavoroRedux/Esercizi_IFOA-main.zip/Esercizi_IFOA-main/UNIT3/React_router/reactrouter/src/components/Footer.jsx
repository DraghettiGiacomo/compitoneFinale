
const Footer = () => {
    return (
        <div className="bg-secondary w-100 text-center">
            <h1>Sono il footer</h1>
        </div>
    )
}

export default Footer