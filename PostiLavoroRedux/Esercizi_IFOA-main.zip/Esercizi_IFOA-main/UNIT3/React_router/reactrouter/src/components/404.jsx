const Nf = () => {
    return (
        <div>
            <h1>Pagina non trovata!</h1>
        </div>
    )
}

export default Nf