const data = [
  {
    id: 1,
    nome: "Fragolino",
    img:
      "https://res.cloudinary.com/thomasdea/image/upload/v1612825605/react-api-course/gelateria/gelato-16_bhll5v.jpg",
    decrizione:
      "Lomo pitchfork gentrify poutine craft beer ugh kale chips. Austin bicycle rights tbh disrupt",
    prezzo: 290,
    categoria: "cono",
  },
  {
    id: 2,
    nome: "Testicolo di Orco",
    img:
      "https://res.cloudinary.com/thomasdea/image/upload/v1612825540/react-api-course/gelateria/gelato-3_nnj0cb.jpg",
    decrizione: " Skateboard dreamcatcher bicycle rights affogato, YOLO edison",
    prezzo: 350,
    categoria: "coppetta",
  },
  {
    id: 6,
    nome: "Banana Joe",
    img:
      "https://res.cloudinary.com/thomasdea/image/upload/v1612825535/react-api-course/gelateria/gelato-14_ga3apr.jpg",
    decrizione:
      "8-bit hashtag vaporware fixie sartorial normcore meggings pour-over cliche",
    prezzo: 130,
    categoria: "stick",
  },
];

export default data;
