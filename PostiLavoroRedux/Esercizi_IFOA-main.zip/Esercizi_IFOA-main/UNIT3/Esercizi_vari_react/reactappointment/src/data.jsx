const data = [
  {
    id: 1,
    nome: "Francesco Robiola",
    stato: "No pain no Gain XOXO PALESTRA MUSCOLI POTENZA",
    img:
      "https://res.cloudinary.com/thomasdea/image/upload/v1612341193/react-api-course/tizio-palestra_naoqwo.jpg",
  },
  {
    id: 2,
    nome: "Sabrina Cortelli",
    stato: "La musica è per l'anima quello che la ginnastica è per il corpo.",
    img:
      "https://res.cloudinary.com/thomasdea/image/upload/v1612341197/react-api-course/tizia-cuffie_xf2bae.jpg",
  },
  {
    id: 3,
    nome: "Mike Russel",
    stato: "Non permettere a nessuno di dirti che non sei capace",
    img:
      "https://res.cloudinary.com/thomasdea/image/upload/v1612341184/react-api-course/tizio-giacca_jvzktv.jpg",
  },
  {
    id: 4,
    nome: "Rebecca Orlando",
    stato:
      "La fotografia è passione e amore, è l’emozione passeggera, che arriva e subito vola via.",
    img:
      "https://res.cloudinary.com/thomasdea/image/upload/v1612341204/react-api-course/tipa-occhiali_svc9jp.jpg",
  },
  {
    id: 5,
    nome: "Crhistian Minerva",
    stato: "Non mangerei un hamburger nemmeno se mi pagassero 40,000 dollari",
    img:
      "https://res.cloudinary.com/thomasdea/image/upload/v1612341200/react-api-course/tizio_awlq7r.jpg",
  },
];

export default data;
