Use state viene utilizzato per gestire lo stato interno del componente


useState [count, setCount] = useState(0) <= posso passare un valore di inizializzazione

per leggere lo stato richiamo {count}
per aggiornare lo stato chiamero il setter "setCount(nuovoValoreStato)"