// GIT ADD index.js (git add index.js)
// GIT COMMIT (git commit -m "First commit")

// GIT PUSH (git push origin develop)

// GIT BRANCH (git branch) visualizza elenco branch nella repo
// GIT CHECKOUT (git checkout main) ci permette di spostarci da un branch all'altro
// GIT CHECKOUT -B (git checkout -b pluto) crea un nuovo branch e ci si sposta
// GIT MERGE (git merge develop) fonde il branch develop con il branch attuale