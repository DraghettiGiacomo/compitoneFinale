import Button from 'react-bootstrap/Button';

const Jumbotron = () => {
    return (
        <div className="text-center my-5">
            <h1>Libreria del centro, benvenuto!</h1>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam quibusdam odio id modi ab error sed unde dicta veritatis officia, nobis totam culpa molestias amet.
            </p>
            <hr />
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam quibusdam odio id modi ab error sed unde dicta veritatis officia, nobis totam culpa molestias amet.
            </p>
            <Button>Scopri di piu</Button>
        </div>
    )
}

export default Jumbotron