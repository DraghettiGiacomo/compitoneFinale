import * as pippo from './index.js';

console.log(pippo);

pippo.allPromiseResolved();