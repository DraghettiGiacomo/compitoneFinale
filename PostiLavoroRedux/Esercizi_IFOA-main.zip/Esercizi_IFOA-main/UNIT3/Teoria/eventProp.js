const main = document.getElementById('main');
// const uno = document.getElementById('uno');
// const due = document.getElementById('due');
// const tre = document.getElementById('tre');



main.addEventListener('click', function (e) {
    e.target.style.backgroundColor = 'blue';
})


// figlio.addEventListener('click', function (e) {
//     e.stopPropagation();
//     figlio.style.backgroundColor = 'blue';
// })

// due.addEventListener('click', function (e) {
//     due.style.backgroundColor = 'blue';
// })

// due.addEventListener('click', function (e) {
//     tre.style.backgroundColor = 'blue';
// })


// const divs = document.querySelectorAll('figghiu');
// divs.forEach(div => {
//     div.addEventListener('click', function (e) {
//         div.target.style.backgroundColor = 'blue';
//     })
// })