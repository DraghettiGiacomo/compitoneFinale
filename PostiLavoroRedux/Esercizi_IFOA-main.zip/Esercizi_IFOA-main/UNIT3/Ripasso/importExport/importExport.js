import { print } from "./module.js";

print(); // print
